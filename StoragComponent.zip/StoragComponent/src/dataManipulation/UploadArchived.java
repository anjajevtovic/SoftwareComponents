package dataManipulation;

import java.io.IOException;

/**
 * Represents abstract model of storage initialisation and storage users manipulation.
 *
 * @author nikola|anja
 */
public interface UploadArchived {

	
	/**
     * @param source data source which contains data for schedule
     * @return Schedule object from JSON
     * @throws IOException IO Exception
     */
	void uploadZip();
	
	/**
     * @param source data source which contains data for schedule
     * @return Schedule object from JSON
     * @throws IOException IO Exception
     */
	void archiveAndUpload();
}
