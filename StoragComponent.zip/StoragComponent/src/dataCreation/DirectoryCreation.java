package dataCreation;

import java.io.IOException;

/**
 * Represents abstract model of storage initialisation and storage users manipulation.
 *
 * @author nikola|anja
 */
public interface DirectoryCreation {
	
	/**
     * @param source data source which contains data for schedule
     * @return Schedule object from JSON
     * @throws IOException IO Exception
     */
	void createDirectory();
	
	/**
     * @param source data source which contains data for schedule
     * @return Schedule object from JSON
     * @throws IOException IO Exception
     */
	void createSetOfDirectories();
	
	/**
     * @param source data source which contains data for schedule
     * @return Schedule object from JSON
     * @throws IOException IO Exception
     */
	void deleteDirectory();
	
	/**
     * @param source data source which contains data for schedule
     * @return Schedule object from JSON
     * @throws IOException IO Exception
     */
	void deleteSetOfDirectories();

}
