package dataCreation;

import java.io.IOException;

/**
 * Represents abstract model of storage initialisation and storage users manipulation.
 *
 * @author nikola|anja
 */
public interface FileCreation {

	/**
     * @param source data source which contains data for schedule
     * @return Schedule object from JSON
     * @throws IOException IO Exception
     */
	void createFile();
	
	/**
     * @param source data source which contains data for schedule
     * @return Schedule object from JSON
     * @throws IOException IO Exception
     */
	void createSetOfFiles();
	
	/**
     * @param source data source which contains data for schedule
     * @return Schedule object from JSON
     * @throws IOException IO Exception
     */
	void deleteFile();
	
	/**
     * @param source data source which contains data for schedule
     * @return Schedule object from JSON
     * @throws IOException IO Exception
     */
	void deleteSetOfFiles();
}
