package model;

public class User {
	
	
	private String username;
	private String password;
	private Boolean isLoggedIn;
	private Integer uploadPriv; 
	private Integer downloadPriv;
	private Integer deletePriv;

}
