package model;

import java.util.ArrayList;
import java.util.List;

public class Storage {
	
	private String storageName;
	private List<User> users;
	private List<String> forbiddenExtensions;
	
}
