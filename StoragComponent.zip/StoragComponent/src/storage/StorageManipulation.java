package storage;

import java.io.IOException;

import model.User;

/**
 * Represents abstract model of storage initialisation and storage users manipulation.
 *
 * @author nikola|anja
 */

public interface StorageManipulation<T> {
	
	/**
     * @param source data source which contains data for schedule
     * @return Schedule object from JSON
     * @throws IOException IO Exception
     */
	void initStorage(String storageName, String username, String password) throws IOException; //StorageAlreadyExistException??
	

	
	/**
     * @param source data source which contains data for schedule
     * @return Schedule object from JSON
     * @throws IOException IO Exception
     */
	void addFrobiddenExtension(String extension);
	
}
