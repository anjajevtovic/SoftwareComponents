package storage;

import java.io.IOException;

/**
 * Represents abstract model of storage initialisation and storage users manipulation.
 *
 * @author nikola|anja
 */

public interface StorageAutentification {
	/**
     * @param source data source which contains data for schedule
     * @return Schedule object from JSON
     * @throws IOException IO Exception
     */
	void logIn();
	
	/**
     * @param source data source which contains data for schedule
     * @return Schedule object from JSON
     * @throws IOException IO Exception
     */
	void logOut();

}
